Config = {}

-- Configuración de las oficinas de la ley
Config.LawOfficeLocations = {
    { coords = vector3(-123.0, 456.0, 78.0), prompt = "Presiona ~INPUT_CONTEXT~ para interactuar", jobaccess = "lawman", showblip = true, blipsprite = 80, blipscale = 0.8, name = "Oficina de Ley" }
}

-- Configuración del blip
Config.Blip = {
    sprite = 80, -- Sprite del blip
    scale = 1.8, -- Escala del blip
    color = 1, -- Color del blip
    name = "Oficina de Ley" -- Nombre del blip
}

-- Configuración del marcador
Config.Marker = {
    rgba = {126, 0, 0, 100}, -- Color y opacidad del marcador
    size = {2.0, 2.0, 0.3}, -- Tamaño del marcador
}

-- Cooldown entre misiones
Config.CooldownBetweenMissions = 5 -- en minutos

-- Duración del blip y el marcador en segundos
Config.BlipDuration = 60 -- en segundos
