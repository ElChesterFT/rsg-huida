local RSGCore = exports['rsg-core']:GetCoreObject()
local blipEntries = {}
local timer = Config.AlertTimer
local cooldownTimer = Config.CooldownBetweenMissions * 60 * 1000 -- en milisegundos
local blipDuration = Config.BlipDuration * 1000 -- Duración en milisegundos

-- Crear los prompts y blips
CreateThread(function()
    for _, v in pairs(Config.LawOfficeLocations) do
        exports['rsg-core']:createPrompt(v.prompt, v.coords, RSGCore.Shared.Keybinds['INTERACT'], 'Interactuar', {
            type = 'client',
            event = 'rsg-lawman:client:mainmenu',
            args = { v.jobaccess },
        })

        -- Crear marcador
        CreateThread(function()
            while true do
                Wait(0)
                local playerPed = PlayerPedId()
                local playerCoords = GetEntityCoords(playerPed)
                local distance = #(v.coords - playerCoords)

                if distance < 10.0 then
                    DrawMarker(1, v.coords.x, v.coords.y, v.coords.z - 1.0, 0, 0, 0, 0, 0, 0, Config.Marker.size[1], Config.Marker.size[2], Config.Marker.size[3], Config.Marker.rgba[1], Config.Marker.rgba[2], Config.Marker.rgba[3], Config.Marker.rgba[4], false, true, 2, false, false, false, false)
                end

                -- Eliminar marcador después de la duración
                CreateThread(function()
                    Wait(blipDuration)
                    -- No hay una función para eliminar el marcador, se hace al salir de la proximidad
                end)
            end
        end)
    end
end)

RegisterNetEvent('rsg-lawman:client:lawmanAlert', function(coords, text)
    RSGCore.Functions.GetPlayerData(function(PlayerData)
        -- Verificar si el trabajo del jugador es 'vallaw' o 'rholaw'
        if PlayerData.job.type == "vallaw" or PlayerData.job.type == "rholaw" then
            local blip = AddBlipForCoord(coords)
            SetBlipSprite(blip, Config.Blip.sprite)
            SetBlipScale(blip, Config.Blip.scale)
            SetBlipColour(blip, Config.Blip.color)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentSubstringPlayerName(text)
            EndTextCommandSetBlipName(blip)
            table.insert(blipEntries, {coords = coords, handle = blip})

            -- Ruta GPS
            if Config.AddGPSRoute then
                StartGpsMultiRoute(3, true, true)
                AddPointToGpsMultiRoute(coords)
                SetGpsMultiRouteRender(true)
            end

            -- Notificación
            RSGCore.Functions.Notify(text, 'inform')

            -- Temporizador
            CreateThread(function ()
                Wait(blipDuration)
                RemoveBlip(blip)
                if Config.AddGPSRoute then
                    ClearGpsMultiRoute()
                end
            end)
        end
    end)
end)
