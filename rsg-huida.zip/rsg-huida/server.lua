local RSGCore = exports['rsg-core']:GetCoreObject()

RSGCore.Commands.Add('huida', 'Emitir una alerta de huida', {{name = 'text', help = 'Texto de la alerta'}}, false, function(source, args)
    local text = table.concat(args, " ")
    local src = source
    local playerCoords = GetEntityCoords(GetPlayerPed(src))
    
    -- Enviar el evento a todos los clientes
    TriggerClientEvent('rsg-lawman:client:lawmanAlert', -1, playerCoords, text)
end)
