fx_version 'cerulean'
game 'rdr3'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'


author 'chesterFt'
description 'Script de alerta de huida para RDR3'
version '1.0.0'

-- Dependencias
dependency 'rsg-core'
dependency 'rsg-lawman'

-- Archivos de cliente
client_scripts {
    'client/*.lua'
}

-- Archivos de servidor
server_scripts {
    'server/*.lua'
}

-- Archivos de configuración
files {
    'config.lua'
}

-- Archivo de configuración
lua54 'yes'
